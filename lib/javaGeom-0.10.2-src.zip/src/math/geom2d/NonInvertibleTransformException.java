/**
 * 
 */

package math.geom2d;

/**
 * @author dlegland
 * @deprecated replaced by NonInvertibleTransform2DException (0.9.0)
 */
@Deprecated
public class NonInvertibleTransformException extends NonInvertibleTransform2DException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public NonInvertibleTransformException() {
    }
}
